

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Verifique seu endereço de Email')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Um novo link de verificação foi enviado para o seu endereço de e-mail.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Antes de continuar, verifique seu e-mail para obter um link de verificação.')); ?>

                    <?php echo e(__('Se você não recebeu o email')); ?>,
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('clique aqui para solicitar outro')); ?></button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rafael.black\Documents\GitHub\Trabalho-Final\resources\views/auth/verify.blade.php ENDPATH**/ ?>