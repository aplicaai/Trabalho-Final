<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
        	<?php echo e(__('Copyright © '.date("Y").' Radmin v2.6.0. Crafted with')); ?> 
        	<i class="fa fa-heart text-danger"></i> 
        	<a href="http://lavalite.org/" class="text-dark" target="_blank">
        		<?php echo e(__('Lavalite')); ?>

        	</a>
        </span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">
        	<?php echo e(__('Developed by')); ?> 
        	<a href="https://rakibul.dev" class="text-dark" target="_blank">
        		<?php echo e(__('Md. Rakibul Islam')); ?>

        	</a>
        </span>
    </div>
</footer><?php /**PATH C:\Users\rafael.black\Documents\GitHub\Trabalho-Final\resources\views/include/footer.blade.php ENDPATH**/ ?>